namespace SCIABackendDemo.Hubs
{
    using Microsoft.AspNetCore.SignalR;

    public class LogHub : Hub
    {
        // Este hub se usará para enviar mensajes de log.
    }
}
