namespace SCIABackendDemo.Configuration
{
    public class UltravoxOptions
    {
        public string ApiKey       { get; set; } = null!;
        public string VoiceId      { get; set; } = null!;
        public string SystemPrompt { get; set; } = null!;
    }
}
