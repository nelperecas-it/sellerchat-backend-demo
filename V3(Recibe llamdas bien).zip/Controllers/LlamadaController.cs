using System;
using System.Text.Json;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.Configuration;
using Serilog;
using Twilio;
using Twilio.TwiML;

using Twilio.Rest.Api.V2010.Account;
using Twilio.Types;
using SCIABackendDemo.Hubs;
using SCIABackendDemo.Services;
using SCIABackendDemo.Configuration;

namespace SCIABackendDemo.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class LlamadaController : ControllerBase
    {
        private readonly IHubContext<LogHub> _hubContext;
        private readonly UltravoxService      _ultravoxService;
        private readonly IConfiguration       _configuration;

        public LlamadaController(
            IHubContext<LogHub> hubContext,
            UltravoxService ultravoxService,
            IConfiguration configuration)
        {
            _hubContext       = hubContext;
            _ultravoxService  = ultravoxService;
            _configuration    = configuration;
        }

        // GET api/llamada/listcalls
        [HttpGet("listcalls")]
        public async Task<IActionResult> ListCalls()
        {
            Log.Information("Obteniendo lista de llamadas desde Ultravox.");
            await _hubContext.Clients.All.SendAsync("ReceiveLog", "Obteniendo lista de llamadas...");

            string result = await _ultravoxService.ListCallsAsync();
            Log.Information("Respuesta de Ultravox: {Result}", result);

            using JsonDocument jsonDoc = JsonDocument.Parse(result);
            JsonElement arrayToProcess;

            if (jsonDoc.RootElement.ValueKind == JsonValueKind.Object &&
                jsonDoc.RootElement.TryGetProperty("results", out var results) &&
                results.ValueKind == JsonValueKind.Array)
            {
                arrayToProcess = results;
            }
            else if (jsonDoc.RootElement.ValueKind == JsonValueKind.Array)
            {
                arrayToProcess = jsonDoc.RootElement;
            }
            else
            {
                Log.Error("La respuesta de Ultravox no contiene un arreglo en 'results'. Recibido: {Json}", jsonDoc.RootElement);
                return BadRequest("Formato inesperado de datos.");
            }

            var filteredCalls = new List<FilteredCall>();
            foreach (var callElement in arrayToProcess.EnumerateArray())
            {
                filteredCalls.Add(new FilteredCall
                {
                    CallID       = callElement.GetProperty("callId").GetString(),
                    Created      = callElement.GetProperty("created").GetString(),
                    Jorned       = callElement.GetProperty("joined").GetString(),
                    Ended        = callElement.GetProperty("ended").GetString(),
                    Endrason     = callElement.GetProperty("endReason").GetString(),
                    Maxduration  = callElement.GetProperty("maxDuration").GetString(),
                    SystemPrompt = callElement.GetProperty("systemPrompt").GetString(),
                    ShortSummary = callElement.TryGetProperty("shortSummary", out var ss) && ss.ValueKind != JsonValueKind.Null
                                     ? ss.GetString()
                                     : null,
                    Summary      = callElement.TryGetProperty("summary",    out var s)  && s .ValueKind != JsonValueKind.Null
                                     ? s .GetString()
                                     : null
                });
            }

            await _hubContext.Clients.All.SendAsync("ReceiveLog", "Lista de llamadas obtenida y filtrada.");
            return Ok(filteredCalls);
        }

        // POST api/llamada/callto
        [HttpPost("callto")]
        public async Task<IActionResult> CallTo([FromBody] CreateCallRequest req)
        {
            if (string.IsNullOrWhiteSpace(req.Phone))
                return BadRequest("El número destino es obligatorio.");

            // 1) Crear llamada entrante en Ultravox y obtener joinUrl
            var joinUrl = await _ultravoxService.CreateIncomingSipCallAsync();
            Log.Information("joinUrl obtenido de Ultravox: {JoinUrl}", joinUrl);
            await _hubContext.Clients.All.SendAsync("ReceiveLog", $"joinUrl recibido: {joinUrl}");

            // 2) Construir URL de TwiML Bin
            var twimlBinSid = _configuration["Twilio:TwiMLBinSid"];
            var twimlUrl    = new Uri($"https://handler.twilio.com/twiml/{twimlBinSid}?JoinUrl={Uri.EscapeDataString(joinUrl)}");

            // 3) Crear llamada PSTN vía Twilio
            var call = await CallResource.CreateAsync(
                to:   new PhoneNumber(req.Phone),
                from: new PhoneNumber(_configuration["Twilio:PhoneNumber"]),
                url:  twimlUrl
            );

            Log.Information("Twilio CallSid {Sid}", call.Sid);
            await _hubContext.Clients.All.SendAsync("ReceiveLog", $"CallSid Twilio: {call.Sid}");

            return Ok(new { callSid = call.Sid });
        }
    }

    public class CreateCallRequest
    {
        public string Phone { get; set; } = null!;
    }

    public class FilteredCall
    {
        public string? CallID       { get; set; }
        public string? Created      { get; set; }
        public string? Jorned       { get; set; }
        public string? Ended        { get; set; }
        public string? Endrason     { get; set; }
        public string? Maxduration  { get; set; }
        public string? SystemPrompt { get; set; }
        public string? ShortSummary { get; set; }
        public string? Summary      { get; set; }
    }
}
