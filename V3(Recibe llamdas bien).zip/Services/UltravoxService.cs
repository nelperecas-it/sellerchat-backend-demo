using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.Extensions.Options;
using SCIABackendDemo.Configuration;

namespace SCIABackendDemo.Services
{
    public class UltravoxService
    {
        private readonly HttpClient _httpClient;
        private readonly string     _apiKey;
        private readonly string     _voiceId;
        private readonly PromptService _promptService;

        public UltravoxService(HttpClient httpClient,
                               IOptions<UltravoxOptions> opts,
                               PromptService promptService)
        {
            _httpClient    = httpClient;
            _apiKey        = opts.Value.ApiKey;
            _voiceId       = opts.Value.VoiceId;
            _promptService = promptService;
        }

        public async Task<string> ListCallsAsync()
        {
            const string url = "https://api.ultravox.ai/api/calls";
            _httpClient.DefaultRequestHeaders.Remove("X-API-Key");
            _httpClient.DefaultRequestHeaders.Add("X-API-Key", _apiKey);

            var response = await _httpClient.GetAsync(url);
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadAsStringAsync();
        }

        public async Task<string> CreateIncomingSipCallAsync()
        {
            const string url = "https://api.ultravox.ai/api/calls";
            var payload = new
            {
                systemPrompt = _promptService.CurrentPrompt,
                languageHint = "es",
                voice        = _voiceId,
                maxDuration  = "300s",
                medium = new { sip = new { incoming = new { } } }
            };

            var json    = JsonSerializer.Serialize(payload);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            _httpClient.DefaultRequestHeaders.Remove("X-API-Key");
            _httpClient.DefaultRequestHeaders.Add("X-API-Key", _apiKey);

            var resp = await _httpClient.PostAsync(url, content);
            resp.EnsureSuccessStatusCode();
            var body = await resp.Content.ReadAsStringAsync();

            using var doc = JsonDocument.Parse(body);
            return doc.RootElement.GetProperty("joinUrl").GetString()!;
        }
    }
}
